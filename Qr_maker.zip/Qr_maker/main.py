from tkinter import *
import qrcode
from PIL import Image, ImageTk
root=Tk()
root.resizable(False,False)
root.geometry("455x260")
root.title("Qr Code Generator")

def create_qr():
    # qr = qrcode.QRCode(version=1, box_size=10, border=4
    source_path=source.get()
    target_path=target.get()
    img=qrcode.make(source_path)
    img.save(target_path)

image=ImageTk.PhotoImage(Image.open("back2.jpg"))
image_label=Label(root, image=image)
image_label.place(x=0,y=0)

source=StringVar()
l1=Label(root,text="Enter Url:",font=("Bahnschrift",13,"bold"),bg="lightblue")
l1.place(x=85,y=87)
l1_ent=Entry(root,textvariable=source,font=("Courier New",12))
l1_ent.place(x=170,y=87,width=190,height=27)

target=StringVar()
l2=Label(root,text="Enter Url:",font=("Bahnschrift",13,"bold"),bg="lightblue")
l2.place(x=85,y=130)
l2_ent=Entry(root,textvariable=target,font=("Courier New",12))
l2_ent.place(x=170,y=130,width=190,height=27)

create_btn=Button(root,text="Create QR",font=("Bahnschrift",13,"bold"),bd=3,bg="lightblue",command=create_qr)
create_btn.place(x=170,y=170,width=110,height=30)
root.mainloop()